# AirScreen Receiver (kerangka)

Buka folder ini di Android Studio (Hedgehog atau lebih baru), sync Gradle, lalu Run di HP Android.

## Tes
1. HP Android dan iPhone harus di Wi-Fi yang sama.
2. Tap **Mulai**.
3. Di iPhone: Control Center > Screen Mirroring > pilih "AirScreen ...".
4. Lihat log di app. Kalau muncul `← GET /info RTSP/1.0` berarti discovery sudah jalan.
   iPhone akan mentok di tahap berikutnya karena pairing/FairPlay belum dibuat.

## Langkah berikutnya
1. Balas `GET /info` (binary plist)
2. `POST /pair-setup` dan `/pair-verify`
3. `POST /fp-setup` (FairPlay, biasanya lewat kode RPiPlay/UxPlay via NDK, lisensi GPL)
4. Terima stream mirroring, decrypt, H.264 -> MediaCodec -> SurfaceView
5. Audio (AAC/ALAC)

Kalau iPhone tidak melihat device-nya, coba ganti NsdManager dengan library JmDNS.
