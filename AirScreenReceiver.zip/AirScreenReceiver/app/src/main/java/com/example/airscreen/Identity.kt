package com.example.airscreen

import android.content.Context
import android.os.Build
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom

/** Identitas receiver: disimpan supaya iPhone mengenali device yang sama tiap kali. */
class Identity(context: Context) {
    private val prefs = context.getSharedPreferences("identity", Context.MODE_PRIVATE)

    val deviceId: String = prefs.getString("id", null)
        ?: randomMac().also { prefs.edit().putString("id", it).apply() }

    // PLACEHOLDER. Nanti diganti public key Ed25519 asli saat pairing dibuat.
    val publicKeyHex: String = prefs.getString("pk", null)
        ?: randomHex(32).also { prefs.edit().putString("pk", it).apply() }

    val name: String = "AirScreen ${Build.MODEL}"

    private fun randomHex(n: Int) =
        ByteArray(n).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }

    private fun randomMac(): String {
        val b = ByteArray(6).also { SecureRandom().nextBytes(it) }
        b[0] = ((b[0].toInt() and 0xFE) or 0x02).toByte() // locally administered, unicast
        return b.joinToString(":") { "%02X".format(it) }
    }
}

fun localIpv4(): String? = NetworkInterface.getNetworkInterfaces()?.asSequence().orEmpty()
    .filter { it.isUp && !it.isLoopback }
    .flatMap { it.inetAddresses.asSequence() }
    .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
