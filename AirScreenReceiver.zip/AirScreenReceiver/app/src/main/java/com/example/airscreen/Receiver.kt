package com.example.airscreen

import android.content.Context

class Receiver(context: Context, private val log: (String) -> Unit) {
    companion object { const val PORT = 7000 }

    val identity = Identity(context)
    private val mdns = Mdns(context, log)
    private val server = RtspServer(PORT, log)

    fun start(): Boolean = try {
        server.start()
        mdns.start(identity, PORT)
        log("IP: ${localIpv4() ?: "nggak ketemu, cek Wi-Fi"}:$PORT")
        true
    } catch (e: Exception) {
        log("Gagal start: ${e.message}")
        stop()
        false
    }

    fun stop() {
        mdns.stop()
        server.stop()
    }
}
