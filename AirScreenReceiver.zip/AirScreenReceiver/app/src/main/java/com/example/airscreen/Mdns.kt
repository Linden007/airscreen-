package com.example.airscreen

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager

/** Umumkan service _raop._tcp dan _airplay._tcp supaya muncul di Screen Mirroring iPhone. */
class Mdns(context: Context, private val log: (String) -> Unit) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var lock: WifiManager.MulticastLock? = null
    private val listeners = mutableListOf<NsdManager.RegistrationListener>()

    fun start(id: Identity, port: Int) {
        lock = wifi.createMulticastLock("airscreen").apply { setReferenceCounted(false); acquire() }
        val features = "0x5A7FFFF7,0x1E"

        register(NsdServiceInfo().apply {
            serviceName = id.deviceId.replace(":", "") + "@" + id.name
            serviceType = "_raop._tcp"
            this.port = port
            mapOf(
                "txtvers" to "1", "ch" to "2", "cn" to "0,1,3", "da" to "true",
                "et" to "0,3,5", "vv" to "2", "ft" to features, "am" to "AppleTV3,2",
                "md" to "0,1,2", "sr" to "44100", "ss" to "16", "sv" to "false",
                "tp" to "UDP", "vn" to "65537", "vs" to "220.68", "sf" to "0x4",
                "pk" to id.publicKeyHex
            ).forEach { (k, v) -> setAttribute(k, v) }
        })

        register(NsdServiceInfo().apply {
            serviceName = id.name
            serviceType = "_airplay._tcp"
            this.port = port
            mapOf(
                "deviceid" to id.deviceId, "features" to features, "model" to "AppleTV3,2",
                "srcvers" to "220.68", "flags" to "0x4", "vv" to "2", "pk" to id.publicKeyHex
            ).forEach { (k, v) -> setAttribute(k, v) }
        })
    }

    private fun register(info: NsdServiceInfo) {
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) = log("mDNS ok: ${i.serviceType}")
            override fun onRegistrationFailed(i: NsdServiceInfo, code: Int) =
                log("mDNS GAGAL: ${i.serviceType}, kode $code")
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, code: Int) {}
        }
        listeners += l
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        listeners.forEach { runCatching { nsd.unregisterService(it) } }
        listeners.clear()
        lock?.takeIf { it.isHeld }?.release()
        lock = null
    }
}
