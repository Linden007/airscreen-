package com.example.airscreen

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/**
 * Server TCP minimal. Sekarang cuma mencatat request dari iPhone lalu balas 501,
 * supaya kelihatan iPhone sampai tahap mana. Handler asli ditambah di TODO.
 */
class RtspServer(private val port: Int, private val log: (String) -> Unit) {
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        val s = ServerSocket(port).also { server = it }
        pool.execute {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (_: Exception) {
                    break
                }
            }
        }
        log("Server dengar di port $port")
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
    }

    private fun handle(c: Socket) = c.use {
        log("Koneksi dari ${c.inetAddress.hostAddress}")
        val input = c.getInputStream().buffered()
        val out = c.getOutputStream()
        try {
            while (true) {
                val head = readHead(input) ?: break
                val lines = head.trim().split("\r\n")
                log("← ${lines.first()}")
                val headers = lines.drop(1).mapNotNull { l ->
                    l.indexOf(':').takeIf { it > 0 }
                        ?.let { l.substring(0, it).trim().lowercase() to l.substring(it + 1).trim() }
                }.toMap()

                var left = headers["content-length"]?.toIntOrNull() ?: 0
                val buf = ByteArray(4096)
                while (left > 0) {
                    val n = input.read(buf, 0, minOf(left, buf.size))
                    if (n < 0) return@use
                    left -= n
                }

                // TODO: GET /info, POST /pair-setup, POST /fp-setup, SETUP, RECORD, ...
                val cseq = headers["cseq"] ?: "0"
                out.write("RTSP/1.0 501 Not Implemented\r\nCSeq: $cseq\r\nContent-Length: 0\r\n\r\n".toByteArray())
                out.flush()
            }
        } catch (_: Exception) {
        }
        log("Koneksi ditutup")
    }

    private fun readHead(input: InputStream): String? {
        val sb = ByteArrayOutputStream()
        val end = byteArrayOf(13, 10, 13, 10)
        var matched = 0
        while (sb.size() < 16384) {
            val b = input.read()
            if (b == -1) return null
            sb.write(b)
            matched = when {
                b.toByte() == end[matched] -> matched + 1
                b.toByte() == end[0] -> 1
                else -> 0
            }
            if (matched == 4) return String(sb.toByteArray(), Charsets.ISO_8859_1)
        }
        return null
    }
}
