package com.example.airscreen

import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var receiver: Receiver
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var button: Button
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        status = findViewById(R.id.status)
        logView = findViewById(R.id.log)
        button = findViewById(R.id.button)

        receiver = Receiver(applicationContext) { msg ->
            runOnUiThread { logView.text = "$msg\n${logView.text}".take(4000) }
        }
        findViewById<TextView>(R.id.info).text =
            "Nama: ${receiver.identity.name}\nID: ${receiver.identity.deviceId}"

        button.setOnClickListener { toggle() }
    }

    private fun toggle() {
        if (running) {
            receiver.stop()
            running = false
        } else {
            running = receiver.start()
        }
        status.text = if (running) "● Aktif. Cari \"${receiver.identity.name}\" di Screen Mirroring" else "○ Mati"
        button.text = if (running) "Berhenti" else "Mulai"
    }

    override fun onDestroy() {
        receiver.stop()
        super.onDestroy()
    }
}
